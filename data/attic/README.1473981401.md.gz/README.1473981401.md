# Creative Kids Wiki
[![Build Status](https://travis-ci.org/CreativeKids/wiki.svg?branch=master)](https://travis-ci.org/CreativeKids/wiki)

Welcome to the Creative Kids Wiki! This contains documentation and other information shared by students and teachers learning about creative computer programming! Enjoy!

[Writing a Good Project](Writing a Good Project)


